Theme Name:Marketica
Theme URI: http://www.toko.press
Author: TokoPress
Author URI: http://www.toko.press
Description:The Best Marketplace Themes For WordPress and WooCommerce.
Version:2.0
License:GPL License
License URI:license.txt
Tags:one-column, two-columns, right-sidebar, responsive-layout, custom-background, custom-colors, custom-header, custom-menu, featured-images, full-width-template, theme-options, translation-ready
