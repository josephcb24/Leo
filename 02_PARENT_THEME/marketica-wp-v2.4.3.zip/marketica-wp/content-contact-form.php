<?php
/* Backward Compatibility for Marketica v1.x */
tokopress_include_file( 'page-contact-form.php' );
exit;
?>
